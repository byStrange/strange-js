// window.onkeyup = function(e) {
//     if (e.keyCode == 9 || e.keyCode == 13) {
//         input.value = input.value.replace(`$html`, `<DOCTYPE html>
// <html>
// <head>
// 	<meta charset="UTF-8">
// 	<title></title>
// </head>
// <body>

// </body>
// </html>`);
//         input.value = input.value.replace(`$button`, `<button>

// </button>`);
//         input.value = input.value.replace(`$div`, `<div>

// </div>`);
//         input.value = input.value.replace(`$span`, `<span>

// </span>`);
//         input.value = input.value.replace(`$span.`, `<span class=""></span>`);
//         input.value = input.value.replace(`$div.`, `<div class="">

// </div>`);
//         input.value = input.value.replace(`$iframe`, `<iframe src>

//  </iframe>`);
//         input.value = input.value.replace(`$section`, `<section>

// </section>`);
//         input.value = input.value.replace(`link`, `li nk not supported please use style between <style></style> tag`);
//         input.value = input.value.replace(`$style`, `<style type="text/css">

// </style>`)
//     } else if (e.keyCode == 117) {
//         live()
//     }
// }